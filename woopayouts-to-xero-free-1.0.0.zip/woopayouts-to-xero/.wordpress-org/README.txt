Add WordPress.org assets here (banner-772x250.png, icon-256x256.png, screenshots, etc.).
